from django.urls import path
from .views import office_list, office_create, office_update, office_delete

urlpatterns = [
    path('', office_list, name='office_list'),
    path('new/', office_create, name='office_create'),
    path('<int:pk>/edit/', office_update, name='office_update'),
    path('<int:pk>/delete/', office_delete, name='office_delete'),
]